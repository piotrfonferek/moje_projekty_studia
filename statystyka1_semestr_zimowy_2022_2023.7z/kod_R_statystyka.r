#Projekt zaliczneiowy ze Statystyki
#Grzegorz �ucki s185535
#Piotr Fonferek s185514
library(tidyverse)
library(data.table)
library(ggplot2)
library(readxl)
library(e1071)
library(QuantPsyc)
library(nortest)

#wczytanie danych z pliku 2022.csv
HappinessScore <- read_csv("C:\\Users\\piotr\\Desktop\\2022.csv")
#HappinessScore <- read_csv("D:\\Politechnika\\Semestr 5\\Statystyka\\Projekt\\2022.csv")
#HappinessScore <- read_csv("E:\\Semestr 5\\Statystyka\\Projekt\\2022.csv")

#wczytanie danych
HS <- HappinessScore[,3] #zmienna Happiness Score
GDP <- HappinessScore[,7] #zmienna Explained by: GDP per capita

DF <- data.frame(HS, GDP)
HS1 <- DF[,1]
GDP1 <- DF[,2]

#Zadanie 1
#min, 1st qu, median, mean, 3rd qu., max
summary(HS)
summary(GDP)

#wariancje
var(HS)
var(GDP)

#moda, napisanie funkcji mody
getmode <-function(a){
  uniqv <- unique(a)
  uniqv[which.max(tabulate(match(a, uniqv)))]
}

getmode(HS1)
getmode(GDP1)

#odchylenie standardowe
sd(HS1)
sd(GDP1)

#wspolczynnik zmiennosci
cvH <- sd(HS1)/mean(HS1)
cvG <- sd(GDP1)/mean(GDP1)

#rozstep kwartylowy
rkH <- IQR(HS1)
rkG <- IQR(GDP1)

#kwartylowy wspolczynnik zmiennosci
ckH <- rkH/mean(HS1)
ckG <- rkG/mean(GDP1)

#Zadanie 2
#moment trzeci centralny
m3CH <- moment(HS1, order = 3, center = TRUE)
m3CG <- moment(GDP1, order = 3, center = TRUE)
#moment trzeci wzgledny
m3WH <- m3CH/sd(HS1)^3
m3WG <- m3CG/sd(GDP1)^3
#moment czwarty centralny
m4CH <- moment(HS1, order = 4, center = TRUE)
m4CG <- moment(GDP1, order = 4, center = TRUE)
#moment czwarty wzgledny
m4WH <- m4CH/sd(HS1)^4
m4WG <- m4CG/sd(GDP1)^4

#kwartylowy wspolczynnik skosnosci
           
kws <- function(dane){
  ((as.numeric(quantile(dane)[4])-median(dane))-(median(dane)-as.numeric(quantile(dane)[2])))/(as.numeric(quantile(dane)[4])-as.numeric(quantile(dane)[2]))
}
kws(HS1)
kws(GDP1)



#Zadanie 3
#Histogramy dla obu zmiennych
hist(HS1, main="Happiness score", prob = TRUE, col="lightblue")
lines(density(HS1))

hist(GDP1, main="Explained by: GDP per capita", prob = TRUE, col="lightblue")
lines(density(GDP1))
#Zadanie 4
#Testowanie normalnosci rozk�adow zmiennych
#dla HS

test11<-shapiro.test(HS1)
test11
ggplot(DF, aes(sample = HS1)) +
  stat_qq() +
  stat_qq_line()

#dla GDP
test2<-ks.test(DF,"pnorm",mean=mean(GDP1),sd=sd(GDP1))
test21<-shapiro.test(GDP1)
test21
test2
ggplot(DF, aes(sample = GDP1)) +
  stat_qq() +
  stat_qq_line()

#Zadanie 5 (przedzialy ufnosci dla HS1 dla p=0.95)

dwpu <- mean(HS1)-1.96*sd(HS1)/sqrt(146) #dolna wartosc przedzialu ufnosci
gwpu <- mean(HS1)+1.96*sd(HS1)/sqrt(146) #g�rna wartosc przedzialu ufnosci
dwpu
gwpu


#Zadanie 6

mardia <- mult.norm(DF)$mult.test #test mardia dla zmiennych HS1 i GDP
mardia


#Zadanie 8
kor <- cor.test(x=HS1, y=GDP1, method='spearman', exact = FALSE) #wyliczenie wartosci wspolczynnika korelacji rang Spearmana
kor
u <- as.numeric(kor[4])*sqrt(146-1) #test istotnosci wspolczynnika korelacji rang Spearmana 
u

#Zadanie 10

model <- lm(formula = HS1 ~ GDP1) #badanie zwiazku przyczynowo-skutkowego y=f(x) obu badanych zmiennych
summary(model)
plot(GDP1, HS1) #wykres HS1(GDP)
abline(lm) #prosta regresji
